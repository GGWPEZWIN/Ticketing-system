#pragma once 

void displayTrainStations();

const char* trainStationToString(enum TrainStations trainStation);

int getCurrentTimestamp();
