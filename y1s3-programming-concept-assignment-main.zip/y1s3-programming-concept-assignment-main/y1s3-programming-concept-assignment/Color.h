#pragma once

// ANSI colour values defination
#define blue "\033[1;34m"
#define green "\033[1;32m"
#define yellow "\033[1;33m"
#define red "\033[1;31m"
#define reset "\033[0m"
#define bold "\033[1;0m"
#define cyan "\033[1;36m"
#define pink "\033[1;35m"  