#pragma once
struct Date {
	int day;
	int month;
	int year;
};

struct Time {
	int hour;
	int minute;
};



