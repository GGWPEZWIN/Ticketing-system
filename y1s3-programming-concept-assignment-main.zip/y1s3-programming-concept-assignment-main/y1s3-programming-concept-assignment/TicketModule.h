#pragma once
#ifndef tick
#define tick

int Ticket();

#endif 